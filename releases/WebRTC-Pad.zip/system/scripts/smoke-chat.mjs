import {launchTestBrowser} from './browser-fixture.mjs';
// Session chat over real WebRTC; generated video and recording-only game input.
import assert from 'node:assert/strict';
import {once} from 'node:events';
import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {createApp} from '../src/server.js';
const {chromium}=await import(pathToFileURL(process.env.PLAYWRIGHT_MODULE).href);
const errors=[],writes=[],app=createApp({env:{},createInjector:async()=>({name:'Chat test',addController(){},removeController(){},setState(slot,state){writes.push({slot,state});},close(){}})});let browser;
try{
  app.server.listen(0,'127.0.0.1');await once(app.server,'listening');const origin=`http://127.0.0.1:${app.server.address().port}`;
  browser=await launchTestBrowser(chromium,{channel:'msedge',headless:true,args:['--disable-background-timer-throttling','--disable-renderer-backgrounding','--disable-backgrounding-occluded-windows','--disable-features=CalculateNativeWinOcclusion']});
  const pages=[];
  for(let i=0;i<3;i++){
    const context=await browser.newContext({viewport:{width:1440,height:960}});context.setDefaultTimeout(20000);await context.route('**/ice?*',r=>r.fulfill({json:{iceServers:[],iceTransportPolicy:'all'}}));
    await context.addInitScript(()=>{
      for(const mode of ['host','client'])localStorage.setItem(`webrtc-pad:tour-v1:${mode}`,'seen');localStorage.setItem('webrtc-pad:block-local-controller-input:v2','false');localStorage.setItem('webrtc-pad:capture-method','browser');navigator.getGamepads=()=>[];
      navigator.mediaDevices.getDisplayMedia=async()=>{const canvas=document.createElement('canvas');canvas.width=1280;canvas.height=720;const ctx=canvas.getContext('2d');let n=0;const draw=()=>{ctx.fillStyle='#10252d';ctx.fillRect(0,0,1280,720);ctx.fillStyle='#c9f794';ctx.font='30px sans-serif';ctx.fillText('Playing together · demo game',30,50);ctx.beginPath();ctx.arc(80+(n++*3)%1100,360,35,0,7);ctx.fill();ctx.font='18px monospace';ctx.fillText(`Frame ${n}`,30,680);};draw();setInterval(draw,1000/60);return canvas.captureStream(60);};
    });
    const page=await context.newPage();pages.push(page);page.on('pageerror',e=>errors.push(e.message));await page.goto(origin+(i?'/?mode=join':''));await page.evaluate(async()=>{const {SessionChat}=await import('/chat.js'),ready=SessionChat.prototype.setReady;SessionChat.prototype.setReady=function(...args){if(args[0])window.chat=this;return ready.apply(this,args);};});
  }
  const [host,a,b]=pages,side=p=>p===host?'host':'client',root=p=>`#${side(p)}Chat`,sheet=p=>p.locator(`${root(p)}Sheet`),input=p=>p.locator(`${root(p)} [data-chat=input]`);
  const closeButton=p=>sheet(p).getByRole('button',{name:'Close chat',exact:true});
  async function checkFooter(p){
    const [close,note,send,attach]=await Promise.all([closeButton(p).boundingBox(),sheet(p).locator('.chat-session-note').boundingBox(),sheet(p).getByRole('button',{name:'Send message'}).boundingBox(),sheet(p).getByRole('button',{name:'Attach a file'}).boundingBox()]);
    assert.ok(attach && send && Math.abs(attach.y-send.y)<2 && Math.abs(attach.x+attach.width-send.x)<10,'The attachment icon sits directly beside Send');
    assert.ok(close && note && send && close.y>=send.y+send.height && Math.abs(close.x-send.x)<2,'Close sits directly below Send');
    assert.ok(Math.abs(close.y+close.height/2-note.y-note.height/2)<2 && note.x+note.width<=close.x,'Close and the call note share a row');
  }
  const open=async p=>{if(!await sheet(p).evaluate(el=>el.open))await p.locator(`#${side(p)}CallChat`).click();};
  const post=async(p,text)=>{await open(p);await input(p).fill(text);await input(p).press('Enter');await p.waitForFunction(text=>window.chat.history.entries.some(e=>e.text===text),text);};
  const waitText=(p,text)=>p.waitForFunction(text=>window.chat?.history.entries.some(e=>e.text===text),text);
  const join=async p=>{if(!await host.locator('#hostInviteSheet').evaluate(el=>el.open))await host.locator('#inviteFocus').click();const old=await host.locator('#hostInvitation').inputValue();await host.locator(old?'#newInvitation':'#createInvitation').click();await host.waitForFunction(old=>document.querySelector('#hostInvitation').value!==old,old);await p.locator('#clientInvitationFile').setInputFiles({name:'invite.json',mimeType:'application/json',buffer:Buffer.from(await host.locator('#hostInvitation').inputValue())});await p.waitForFunction(()=>!!document.querySelector('#clientReply').value);await host.locator('#hostReplyFile').setInputFiles({name:'reply.json',mimeType:'application/json',buffer:Buffer.from(await p.locator('#clientReply').inputValue())});await p.waitForFunction(()=>window.chat?.synced && document.querySelector('#clientVideo').getVideoPlaybackQuality().totalVideoFrames>10);};
  await host.locator('#chooseBrowserSource').click();await host.waitForFunction(()=>document.querySelector('#hostPreview').videoWidth>0);await host.locator('#hostCreate').click();await join(a);
  await open(host);
  const picker=host.waitForEvent('filechooser');
  await sheet(host).getByRole('button',{name:'Attach a file'}).click();
  assert.equal(await (await picker).element().getAttribute('data-file'),'picker');
  const [hello,send]=await Promise.all([sheet(host).getByText('Say hello to the call.').boundingBox(),sheet(host).getByRole('button',{name:'Send message'}).boundingBox()]);
  assert.ok(hello && send && hello.y+hello.height<=send.y && send.y-hello.y-hello.height<24 && Math.abs(hello.x+hello.width-send.x-send.width)<8,`The empty chat hint sits right above Send: ${JSON.stringify({hello,send})}`);
  assert.ok(await a.evaluate(()=>window.chat.upstream.channel.label==='chat' && window.chat.upstream.channel.ordered && window.chat.upstream.channel.maxRetransmits===null),'Chat must use its own reliable channel');
  await post(host,'Welcome! Press a button on each controller to join.');await checkFooter(host);await waitText(a,'Welcome! Press a button on each controller to join.');await a.waitForFunction(()=>document.querySelector('#clientCallChat .chat-unread').textContent==='1');await a.locator('#clientStage .chat-peek').click();await a.waitForFunction(()=>document.querySelector('#clientChatSheet').open && window.chat.unread===0);await checkFooter(a);
  await post(a,'Ready! I’ll use keyboard controls.');await waitText(host,'Ready! I’ll use keyboard controls.');
  await a.locator('#clientChatSheet .help-button').click();await a.locator('#clientCallControllers').click();await a.locator('#joinKeyboardController').click();await a.waitForFunction(()=>document.querySelector('#clientSlot').textContent.includes('P1'));await a.locator('#controllersSheet .help-button').click();await a.locator('#clientStage').focus();await a.keyboard.down('z');for(let n=0;n<100 && !writes.some(w=>w.state.buttons.a);n++)await a.waitForTimeout(20);assert.ok(writes.some(w=>w.state.buttons.a));await a.keyboard.up('z');
  const start=writes.length;await post(a,'z is my A button. Chat typing stays here.');assert.ok(!writes.slice(start).some(w=>w.state.buttons.a),'Typing chat must not press game buttons');

  await join(b);assert.equal(await b.evaluate(()=>window.chat.history.entries.length),3);assert.equal(await b.evaluate(()=>window.chat.unread),0,'Synced history is not a new-message alert');assert.equal(await b.locator('#clientStage .chat-peek').isVisible(),false);await post(b,'Connected. Thanks for the invite!');for(const p of [host,a])await waitText(p,'Connected. Thanks for the invite!');
  await open(a);await a.locator('#clientChatSheet .help-button').click();await a.locator('#clientFullscreen').click();await a.waitForFunction(()=>document.fullscreenElement?.id==='clientStage');const frames=await a.locator('#clientVideo').evaluate(v=>v.getVideoPlaybackQuality().totalVideoFrames);
  await post(host,'Full screen still has chat — click the message to reply.');await a.locator('#clientStage .chat-peek').click();assert.equal(await sheet(a).isVisible(),true);assert.ok(await sheet(a).evaluate(el=>document.fullscreenElement.contains(el)));await checkFooter(a);await a.waitForFunction(n=>document.querySelector('#clientVideo').getVideoPlaybackQuality().totalVideoFrames>n+10,frames);
  const empty=await sheet(a).evaluate(el=>{const r=el.getBoundingClientRect(),x=r.left+20,y=r.top+55,hit=document.elementFromPoint(x,y);return {x,y,through:!!hit?.closest('#clientStage') && !hit.closest('.chat-sheet')};});assert.ok(empty.through,'Empty floating chat space must let pointer input reach the video');await a.mouse.click(empty.x,empty.y);assert.equal(await sheet(a).evaluate(el=>el.open),true,'Playing through empty chat space must keep messages open');
  await fs.mkdir('.local/screenshots',{recursive:true});await a.screenshot({path:'.local/screenshots/chat-fullscreen.png'});await input(a).fill('Still playing, and chat works here too.');await input(a).press('Enter');await waitText(b,'Still playing, and chat works here too.');await closeButton(a).click();await a.locator('#clientFullscreen').click();await a.waitForFunction(()=>!document.fullscreenElement);await open(a);await a.screenshot({path:'.local/screenshots/chat-call.png'});
  assert.equal(await a.locator('#clientPanel .view-heading h2').isVisible(),false);
  await a.setViewportSize({width:390,height:800});await checkFooter(a);assert.equal(await a.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await a.screenshot({path:'.local/screenshots/chat-phone.png'});
  const stageTop=await a.locator('#clientStage').evaluate(el=>el.getBoundingClientRect().top);
  await closeButton(a).click();assert.equal(await sheet(a).evaluate(el=>el.open),false);
  assert.equal(await a.locator('#clientStage').evaluate(el=>el.getBoundingClientRect().top),stageTop,'Closing chat keeps the picture in place');
  const literal='<img src=x onerror="window.chatInjected=true">';await post(a,literal);await waitText(host,literal);assert.equal(await host.locator('#hostChat .chat-message img').count(),0);assert.equal(await host.evaluate(()=>!!window.chatInjected),false);
  await host.evaluate(()=>{for(let n=0;n<100;n++)window.chat.accept('host',{request:`history-${n}`,text:`Earlier message ${n}`});});
  await waitText(a,'Earlier message 99');
  const log=a.locator('#clientChat [role=log]'),latest=sheet(a).locator('[data-chat=latest]');
  const anchor=log.getByText('Earlier message 50',{exact:true});
  await log.evaluate(el=>{el.scrollTop=[...el.children].find(row=>row.lastElementChild.textContent==='Earlier message 50').offsetTop-8;});
  await latest.getByText('Latest messages',{exact:true}).waitFor();
  const readingPosition=(await anchor.boundingBox()).y;
  await post(host,'First new message while reading');await waitText(a,'First new message while reading');
  await latest.getByText('1 new message',{exact:true}).waitFor();
  await post(host,'Second new message while reading');await waitText(a,'Second new message while reading');
  await latest.getByText('2 new messages',{exact:true}).waitFor();
  assert.ok(Math.abs((await anchor.boundingBox()).y-readingPosition)<2,'The message being read must stay in place as old history expires');
  await latest.click();await latest.waitFor({state:'hidden'});
  await post(host,'Follow new messages again');await waitText(a,'Follow new messages again');
  assert.ok(await log.evaluate(el=>el.scrollHeight-el.scrollTop-el.clientHeight<2),'Chat follows new messages after returning to the bottom');
  assert.equal(await latest.isVisible(),false);
  await a.setViewportSize({width:1440,height:960});await host.evaluate(()=>{window.blockedChat=[...window.chat.links.values()][0];Object.defineProperty(window.blockedChat.channel,'bufferedAmount',{configurable:true,get:()=>65536});for(let n=0;n<200;n++)window.chat.accept('host',{request:`test-${n}`,text:`Session note ${n}`});});await host.waitForFunction(()=>window.blockedChat.resync===true);
  await open(a);await input(a).fill('Chat caught up after a busy connection.');await input(a).press('Enter');await waitText(host,'Chat caught up after a busy connection.');assert.ok(await a.evaluate(()=>!!window.chat.pending));await host.evaluate(()=>delete window.blockedChat.channel.bufferedAmount);for(const p of pages)await p.waitForFunction(()=>window.chat.history.entries.length===100 && window.chat.history.entries.at(-1).text==='Chat caught up after a busy connection.');await a.waitForFunction(()=>!window.chat.pending && document.querySelector('#clientChat [data-chat=input]').value==='');
  for(const p of pages)assert.equal(await p.evaluate(()=>Object.keys(localStorage).some(key=>key.includes('chat'))),false,'Call messages must never be persisted to local storage');
  await host.locator('#hostEnd').click();for(const p of pages)await p.waitForFunction(()=>!window.chat.ready && window.chat.history.entries.length===0);await host.locator('#hostCreate').click();await host.waitForFunction(()=>window.chat.ready && window.chat.history.entries.length===0);assert.deepEqual(errors,[]);
  console.log('PASS: dedicated reliable chat channel; three-way messages; late-join history; unread previews and fullscreen replies; scroll position and return to latest messages; literal text safety; keyboard-controller isolation; compact desktop/phone layout; bounded memory; session-end and next-call reset; video continues during chat.');
}catch(error){console.error('Chat smoke failed:',error.message);for(const context of browser?.contexts() || [])for(const p of context.pages())if(p.url().startsWith('http'))console.error(await p.evaluate(()=>({mode:document.body.dataset.mode,error:document.querySelector('#clientStatus')?.textContent,chat:window.chat && {ready:window.chat.ready,synced:window.chat.synced,entries:window.chat.history.entries.length,links:window.chat.links.size,upstream:window.chat.upstream?.channel.readyState}})));throw error;}finally{await browser?.close();await app.close();}
